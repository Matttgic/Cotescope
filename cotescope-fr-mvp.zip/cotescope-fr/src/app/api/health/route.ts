export async function GET() {
  return Response.json({
    ok: true,
    service: "cotescope-fr",
    mode: process.env.ODDS_PROVIDER || "demo",
    timestamp: new Date().toISOString()
  });
}
