import { DEMO_OPPORTUNITIES } from "@/data/demo";

export async function GET() {
  const provider = process.env.ODDS_PROVIDER || "demo";
  return Response.json({
    provider,
    demo: provider === "demo",
    generatedAt: new Date().toISOString(),
    opportunities: DEMO_OPPORTUNITIES
  });
}
