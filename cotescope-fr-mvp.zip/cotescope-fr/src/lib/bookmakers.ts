// Domains currently listed by ANJ as authorised sports-betting websites in France.
// Review periodically against https://www.anj.fr/offre-de-jeu-et-marche/operateurs-agrees
export const ANJ_SPORTS_BOOKMAKERS = [
  "bet365.fr",
  "betclic.fr",
  "betsson.fr",
  "bwin.fr",
  "circusbet.fr",
  "feelingbet.fr",
  "genybet.fr",
  "netbet.fr",
  "netbetsport.fr",
  "olybet.fr",
  "pmu.fr",
  "pokerstars.fr",
  "betstars.fr",
  "pokerstarsmobile.fr",
  "pokerstarssports.fr",
  "unibet.fr",
  "vbet.fr",
  "winamax.fr",
  "zebet.fr"
] as const;

export const BOOKMAKER_LABELS: Record<string, string> = {
  "bet365.fr": "Bet365",
  "betclic.fr": "Betclic",
  "betsson.fr": "Betsson",
  "bwin.fr": "Bwin",
  "circusbet.fr": "CircusBet",
  "feelingbet.fr": "FeelingBet",
  "genybet.fr": "Genybet",
  "netbet.fr": "NetBet",
  "netbetsport.fr": "NetBet Sport",
  "olybet.fr": "OlyBet",
  "pmu.fr": "PMU",
  "pokerstars.fr": "PokerStars Sports",
  "betstars.fr": "BetStars",
  "pokerstarsmobile.fr": "PokerStars Mobile",
  "pokerstarssports.fr": "PokerStars Sports",
  "unibet.fr": "Unibet",
  "vbet.fr": "VBET",
  "winamax.fr": "Winamax",
  "zebet.fr": "ZEbet"
};
